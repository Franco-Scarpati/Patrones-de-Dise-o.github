namespace DomainModel;

public enum Plan { Clasico, Plus, Premium }
