namespace DomainModel;

// Visitor: una operacion por cada tipo exportable.
public interface IExportVisitor
{
    string Visit(Producto p);
    string Visit(Cliente c);
    string Visit(Pedido pe);
}
