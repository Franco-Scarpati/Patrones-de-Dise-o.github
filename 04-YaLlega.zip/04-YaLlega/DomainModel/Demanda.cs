namespace DomainModel;

public enum Demanda { Baja, Media, Alta, Promocion }
