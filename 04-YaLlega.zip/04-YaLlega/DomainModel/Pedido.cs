using System.Collections.Generic;

namespace DomainModel;

public class Pedido : IExportable
{
    public int Id { get; set; }
    public Cliente Cliente { get; set; }
    public List<Producto> Productos { get; set; } = new List<Producto>();
    public decimal TarifaEnvioAplicada { get; set; }
    public string ModoEnvio { get; set; }
    public bool MenuDesdeServidor { get; set; }
    public int IntentosRechazados { get; set; }
    public string Accept(IExportVisitor v) => v.Visit(this);
}
