using System;
using System.Collections.Generic;
using DomainModel;
using BLL;

namespace UI;

class Program
{
    static void Main()
    {
        try { Run(); }
        catch (Exception ex) { Console.WriteLine(); Console.WriteLine("### ERROR EN TIEMPO DE EJECUCION ###"); Console.WriteLine(ex); }
        Console.WriteLine();
        Console.WriteLine("Fin. Presione una tecla para cerrar...");
        Console.ReadKey();
    }

    static void Run()
    {
        Console.WriteLine("=== YaLlega (Strategy + Proxy + Visitor + Repository) ===");
        var cliente = new Cliente { Id = 1, Nombre = "Franco", Plan = Plan.Clasico };
        var empanadas = new Producto { Id = 1, Nombre = "Empanadas", Precio = 3000, PlanMinimo = Plan.Clasico };
        var sushi = new Producto { Id = 2, Nombre = "Sushi Premium", Precio = 12000, PlanMinimo = Plan.Premium };

        var service = AppFactory.CrearPedidoService();
        var pedido = service.NuevoPedido(cliente);

        service.AgregarProducto(pedido, empanadas); // ok (servidor)
        service.AgregarProducto(pedido, empanadas); // desde dispositivo (cache)
        service.AgregarProducto(pedido, sushi);     // BLOQUEADO (plan clasico)

        Console.WriteLine();
        Console.WriteLine("-- Costo de envio segun demanda (Strategy) --");
        service.SetDemanda(Demanda.Baja);      Console.WriteLine("Baja:  " + service.CalcularEnvio());
        service.SetDemanda(Demanda.Media);     Console.WriteLine("Media: " + service.CalcularEnvio());
        service.SetDemanda(Demanda.Alta);      Console.WriteLine("Alta:  " + service.CalcularEnvio());
        service.SetDemanda(Demanda.Promocion); Console.WriteLine("Promo: " + service.CalcularEnvio());

        var confirmado = service.Confirmar(pedido);
        Console.WriteLine("Pedidos guardados: " + service.Historial().Count);

        Console.WriteLine();
        Console.WriteLine("-- Exportar listado (Visitor) --");
        var export = AppFactory.CrearExportService();
        var listado = new List<IExportable> { cliente, empanadas, sushi, confirmado };
        Console.Write(export.Exportar(listado));
    }
}
