using DomainModel;
using DAL;
using Services;

namespace BLL;

public static class AppFactory
{
    public static PedidoService CrearPedidoService()
        => new PedidoService(new RepositorioMemoria<Pedido>(), new ConsoleLogger());

    public static ExportService CrearExportService() => new ExportService();
}
