namespace BLL.Patrones;

// Strategy: la forma de calcular el envio segun la demanda (o el modo que fuerza el operador).
public interface IEstrategiaEnvio
{
    string Nombre { get; }
    decimal Calcular(decimal tarifaBase);
}
public class EnvioNormal : IEstrategiaEnvio
{
    public string Nombre => "Normal";
    public decimal Calcular(decimal tarifaBase) => tarifaBase;
}
public class EnvioMedia : IEstrategiaEnvio
{
    public string Nombre => "Media (+25%)";
    public decimal Calcular(decimal tarifaBase) => tarifaBase * 1.25m;
}
public class EnvioAlta : IEstrategiaEnvio
{
    public string Nombre => "Alta (+60%)";
    public decimal Calcular(decimal tarifaBase) => tarifaBase * 1.60m;
}
public class EnvioPromocion : IEstrategiaEnvio
{
    public string Nombre => "Promocion (gratis)";
    public decimal Calcular(decimal tarifaBase) => 0m;
}
