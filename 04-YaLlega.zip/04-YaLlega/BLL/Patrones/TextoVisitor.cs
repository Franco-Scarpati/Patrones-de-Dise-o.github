using DomainModel;

namespace BLL.Patrones;

// ConcreteVisitor: exporta cualquier elemento a una linea de texto.
public class TextoVisitor : IExportVisitor
{
    public string Visit(Producto p) => "PRODUCTO;" + p.Nombre + ";" + p.Precio + ";plan=" + p.PlanMinimo;
    public string Visit(Cliente c) => "CLIENTE;" + c.Nombre + ";plan=" + c.Plan;
    public string Visit(Pedido pe) => "PEDIDO;" + (pe.Cliente != null ? pe.Cliente.Nombre : "?")
        + ";items=" + pe.Productos.Count + ";envio=" + pe.TarifaEnvioAplicada;
}
