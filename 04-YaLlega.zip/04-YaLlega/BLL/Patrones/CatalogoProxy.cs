using System.Collections.Generic;
using DomainModel;

namespace BLL.Patrones;

public class ResultadoConsulta
{
    public bool Permitido { get; set; }
    public bool DesdeServidor { get; set; }
    public string Detalle { get; set; }
}

public interface ICatalogo { ResultadoConsulta Consultar(Cliente c, Producto p); }

// RealSubject: el catalogo vive en un servidor remoto.
public class CatalogoRemoto : ICatalogo
{
    public ResultadoConsulta Consultar(Cliente c, Producto p)
        => new ResultadoConsulta { Permitido = true, DesdeServidor = true, Detalle = "descargado del servidor: " + p.Nombre };
}

// Proxy: bloquea segun el plan y cachea los ultimos 5 menus consultados.
public class CatalogoProxy : ICatalogo
{
    private readonly CatalogoRemoto _real = new CatalogoRemoto();
    private readonly LinkedList<string> _cache = new LinkedList<string>();

    public ResultadoConsulta Consultar(Cliente c, Producto p)
    {
        if ((int)c.Plan < (int)p.PlanMinimo)
            return new ResultadoConsulta { Permitido = false, DesdeServidor = false,
                Detalle = "BLOQUEADO: " + p.Nombre + " requiere plan " + p.PlanMinimo };

        if (_cache.Contains(p.Nombre))
            return new ResultadoConsulta { Permitido = true, DesdeServidor = false,
                Detalle = "desde dispositivo (cache): " + p.Nombre };

        var r = _real.Consultar(c, p);           // delega al remoto
        _cache.AddFirst(p.Nombre);
        if (_cache.Count > 5) _cache.RemoveLast();
        return r;
    }
}
