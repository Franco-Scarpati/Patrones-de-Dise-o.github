using System.Collections.Generic;
using DomainModel;
using DAL;
using Services;
using BLL.Patrones;

namespace BLL;

public class PedidoService
{
    private readonly IRepositorio<Pedido> _repo;
    private readonly ILogger _logger;
    private readonly ICatalogo _catalogo;
    private IEstrategiaEnvio _estrategia = new EnvioNormal();
    private const decimal TarifaBase = 500m;

    public PedidoService(IRepositorio<Pedido> repo, ILogger logger)
    {
        _repo = repo; _logger = logger;
        _catalogo = new CatalogoProxy();
    }

    // El sistema mide la demanda, o el operador fuerza un modo:
    // cambia la estrategia aunque el pedido siga abierto.
    public void SetDemanda(Demanda d)
    {
        switch (d)
        {
            case Demanda.Media: _estrategia = new EnvioMedia(); break;
            case Demanda.Alta: _estrategia = new EnvioAlta(); break;
            case Demanda.Promocion: _estrategia = new EnvioPromocion(); break;
            default: _estrategia = new EnvioNormal(); break;
        }
        _logger.Log("Modo de envio: " + _estrategia.Nombre);
    }

    public Pedido NuevoPedido(Cliente cliente) => new Pedido { Cliente = cliente };

    public bool AgregarProducto(Pedido pedido, Producto producto)
    {
        var r = _catalogo.Consultar(pedido.Cliente, producto);
        _logger.Log(r.Detalle);
        if (!r.Permitido)
        {
            pedido.IntentosRechazados++;
            return false;
        }
        pedido.Productos.Add(producto);
        pedido.MenuDesdeServidor = r.DesdeServidor;
        return true;
    }

    public decimal CalcularEnvio() => _estrategia.Calcular(TarifaBase);

    public Pedido Confirmar(Pedido pedido)
    {
        pedido.TarifaEnvioAplicada = CalcularEnvio();
        pedido.ModoEnvio = _estrategia.Nombre;
        _repo.Agregar(pedido);
        _logger.Log("Pedido confirmado. Envio " + pedido.TarifaEnvioAplicada
            + " (" + pedido.ModoEnvio + "), rechazados=" + pedido.IntentosRechazados);
        return pedido;
    }

    public List<Pedido> Historial() => _repo.ObtenerTodos();
}
