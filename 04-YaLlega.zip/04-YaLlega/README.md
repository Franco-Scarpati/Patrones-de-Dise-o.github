# YaLlega - Pedidos y entregas a domicilio

| Patron | Donde | Para que |
| --- | --- | --- |
| Strategy | BLL/Patrones/EstrategiaEnvio | Costo de envio: Normal, Media (+25%), Alta (+60%), Promocion (gratis). Se cambia aunque el pedido siga abierto o lo fuerce el operador. |
| Proxy | BLL/Patrones/CatalogoProxy | Catalogo remoto: bloquea productos fuera del plan (Clasico/Plus/Premium) y cachea los ultimos 5 menus. La pantalla no distingue servidor/dispositivo. |
| Visitor | BLL/Patrones/TextoVisitor | Exporta cualquier listado (productos, clientes, pedidos) a texto con una unica rutina, sirve para clases futuras. |
| Repository | DAL | Persiste cada pedido: cliente, productos, tarifa aplicada, origen del menu, intentos rechazados. |

Capas: DomainModel, DAL, Services, BLL, UI, Tests. UI solo llama a BLL (AppFactory).

Ejecutar: abri `YaLlega.sln`, proyecto de inicio UI, F5 (o `dotnet run --project UI`).
Tests: Test Explorer, o `dotnet test`.
