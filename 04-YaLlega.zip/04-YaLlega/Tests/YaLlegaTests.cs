using System.Collections.Generic;
using DomainModel;
using BLL;
using BLL.Patrones;
using Xunit;

namespace Tests;

public class YaLlegaTests
{
    [Fact] public void EnvioNormal_SinRecargo() => Assert.Equal(500m, new EnvioNormal().Calcular(500m));
    [Fact] public void EnvioMedia_Recargo25() => Assert.Equal(625m, new EnvioMedia().Calcular(500m));
    [Fact] public void EnvioAlta_Recargo60() => Assert.Equal(800m, new EnvioAlta().Calcular(500m));
    [Fact] public void EnvioPromocion_Gratis() => Assert.Equal(0m, new EnvioPromocion().Calcular(500m));

    [Fact]
    public void Proxy_BloqueaProductoSobrePlan()
    {
        var proxy = new CatalogoProxy();
        var cli = new Cliente { Plan = Plan.Clasico };
        var prod = new Producto { Nombre = "Sushi", PlanMinimo = Plan.Premium };
        Assert.False(proxy.Consultar(cli, prod).Permitido);
    }

    [Fact]
    public void Proxy_SegundaConsultaVieneDeCache()
    {
        var proxy = new CatalogoProxy();
        var cli = new Cliente { Plan = Plan.Premium };
        var prod = new Producto { Nombre = "Sushi", PlanMinimo = Plan.Clasico };
        Assert.True(proxy.Consultar(cli, prod).DesdeServidor);   // 1ra: servidor
        Assert.False(proxy.Consultar(cli, prod).DesdeServidor);  // 2da: cache
    }

    [Fact]
    public void Pedido_CuentaRechazadosYAplicaModo()
    {
        var service = AppFactory.CrearPedidoService();
        var cli = new Cliente { Nombre = "Test", Plan = Plan.Clasico };
        var pedido = service.NuevoPedido(cli);
        service.AgregarProducto(pedido, new Producto { Nombre = "Premium", PlanMinimo = Plan.Premium });
        Assert.Equal(1, pedido.IntentosRechazados);
        service.SetDemanda(Demanda.Alta);
        var c = service.Confirmar(pedido);
        Assert.Equal(800m, c.TarifaEnvioAplicada);
    }

    [Fact]
    public void Visitor_ExportaProductoClientePedido()
    {
        var export = AppFactory.CrearExportService();
        var txt = export.Exportar(new List<IExportable>
        {
            new Producto { Nombre = "Emp", Precio = 100, PlanMinimo = Plan.Clasico },
            new Cliente { Nombre = "Ana", Plan = Plan.Plus }
        });
        Assert.Contains("PRODUCTO;Emp", txt);
        Assert.Contains("CLIENTE;Ana", txt);
    }
}
