using DomainModel;
using System.Collections.Generic;

namespace BLL.Patrones;

public interface IContenido { string Reproducir(Contenido c); }

// RealSubject: trae el contenido del servidor remoto.
public class ContenidoRemoto : IContenido
{
    public string Reproducir(Contenido c) => "descargado del servidor: " + c.Titulo;
}

// Proxy: controla el plan (proteccion) y cachea los ultimos 5 (virtual).
public class ContenidoProxy : IContenido
{
    private readonly ContenidoRemoto _real = new ContenidoRemoto();
    private readonly Plan _plan;
    private readonly LinkedList<string> _cache = new LinkedList<string>();

    public ContenidoProxy(Plan plan) { _plan = plan; }

    public string Reproducir(Contenido c)
    {
        if (c.EsPremium && _plan != Plan.Premium)
            return "BLOQUEADO: tu plan no incluye " + c.Titulo;

        if (_cache.Contains(c.Titulo))
            return "desde cache: " + c.Titulo;

        var r = _real.Reproducir(c);
        _cache.AddFirst(c.Titulo);
        if (_cache.Count > 5) _cache.RemoveLast();
        return r;
    }
}
