using DomainModel;

namespace BLL.Patrones;

// ConcreteVisitor: exporta cualquier elemento a una linea de texto.
public class TextoVisitor : IExportVisitor
{
    public string Visit(Contenido c) => "CONTENIDO;" + c.Titulo + ";premium=" + c.EsPremium;
    public string Visit(Usuario u) => "USUARIO;" + u.Nombre + ";plan=" + u.Plan;
}
