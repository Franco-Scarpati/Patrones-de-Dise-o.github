namespace BLL.Patrones;

// Strategy: como se elige la calidad segun el ancho de banda.
public interface IEstrategiaCalidad { string Elegir(int anchoBanda); }

public class CalidadAutomatica : IEstrategiaCalidad
{
    public string Elegir(int anchoBanda)
        => anchoBanda > 50 ? "4K" : anchoBanda > 20 ? "HD" : "baja";
}
public class ModoAhorro : IEstrategiaCalidad
{
    public string Elegir(int anchoBanda) => "baja"; // siempre baja
}
