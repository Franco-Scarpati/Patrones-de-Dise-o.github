using DAL;
using DomainModel;
using Services;

namespace BLL;

public static class AppFactory
{
    public static ReproductorService CrearReproductorService(Plan plan)
        => new ReproductorService(new RepositorioMemoria<Reproduccion>(), new ConsoleLogger(), plan);

    public static ExportService CrearExportService() => new ExportService();
}
