using BLL.Patrones;
using DAL;
using DomainModel;
using Services;
using System.Collections.Generic;

namespace BLL;

public class ReproductorService
{
    private readonly IRepositorio<Reproduccion> _repo;
    private readonly ILogger _logger;
    private readonly IContenido _contenido;
    private IEstrategiaCalidad _estrategia = new CalidadAutomatica();

    public ReproductorService(IRepositorio<Reproduccion> repo, ILogger logger, Plan plan)
    {
        _repo = repo; _logger = logger;
        _contenido = new ContenidoProxy(plan); // Proxy con el plan del usuario
    }

    public void SetModoAhorro(bool activo)
        => _estrategia = activo ? (IEstrategiaCalidad)new ModoAhorro() : new CalidadAutomatica();

    public string Reproducir(Usuario u, Contenido c, int anchoBanda)
    {
        var calidad = _estrategia.Elegir(anchoBanda);       // Strategy
        var resultado = _contenido.Reproducir(c);           // Proxy
        _repo.Agregar(new Reproduccion { Titulo = c.Titulo, Calidad = calidad, UsuarioNombre = u.Nombre });
        _logger.Log(u.Nombre + " -> " + resultado + " @" + calidad);
        return resultado + " @" + calidad;
    }

    public List<Reproduccion> Historial() => _repo.ObtenerTodos();
}
