using System.Collections.Generic;
using DomainModel;
using BLL;
using BLL.Patrones;
using Xunit;

namespace Tests;

public class SarazaFlixTests
{
    [Theory]
    [InlineData(60, "4K")]
    [InlineData(30, "HD")]
    [InlineData(10, "baja")]
    public void CalidadAutomatica_SegunAnchoBanda(int ancho, string esperado)
        => Assert.Equal(esperado, new CalidadAutomatica().Elegir(ancho));

    [Fact]
    public void ModoAhorro_SiempreBaja()
        => Assert.Equal("baja", new ModoAhorro().Elegir(100));

    [Fact]
    public void Proxy_BloqueaPremiumSiPlanBasico()
    {
        var proxy = new ContenidoProxy(Plan.Basico);
        var r = proxy.Reproducir(new Contenido { Titulo = "X", EsPremium = true });
        Assert.StartsWith("BLOQUEADO", r);
    }

    [Fact]
    public void Proxy_PermitePremiumSiPlanPremium()
    {
        var proxy = new ContenidoProxy(Plan.Premium);
        var r = proxy.Reproducir(new Contenido { Titulo = "X", EsPremium = true });
        Assert.StartsWith("descargado", r);
    }

    [Fact]
    public void Visitor_ExportaContenidoYUsuario()
    {
        var export = AppFactory.CrearExportService();
        var txt = export.Exportar(new List<IExportable>
        {
            new Contenido { Titulo = "Serie", EsPremium = false },
            new Usuario { Nombre = "Ana", Plan = Plan.Premium }
        });
        Assert.Contains("CONTENIDO;Serie", txt);
        Assert.Contains("USUARIO;Ana", txt);
    }
}
