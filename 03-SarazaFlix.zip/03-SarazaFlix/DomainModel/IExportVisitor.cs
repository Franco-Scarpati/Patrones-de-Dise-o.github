namespace DomainModel;

// Visitor: una operacion por cada tipo de elemento exportable.
public interface IExportVisitor
{
    string Visit(Contenido c);
    string Visit(Usuario u);
}
