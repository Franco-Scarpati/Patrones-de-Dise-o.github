namespace DomainModel;

public enum Plan { Basico, Estandar, Premium }
