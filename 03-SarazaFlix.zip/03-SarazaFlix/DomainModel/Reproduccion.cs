namespace DomainModel;

public class Reproduccion
{
    public string Titulo { get; set; }
    public string Calidad { get; set; }
    public string UsuarioNombre { get; set; }
}
