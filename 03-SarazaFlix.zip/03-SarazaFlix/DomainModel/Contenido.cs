namespace DomainModel;

public class Contenido : IExportable
{
    public int Id { get; set; }
    public string Titulo { get; set; }
    public bool EsPremium { get; set; }
    public string Accept(IExportVisitor v) => v.Visit(this);
}
