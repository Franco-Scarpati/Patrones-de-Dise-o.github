using System;
using System.Collections.Generic;
using DomainModel;
using BLL;

namespace UI;

class Program
{
    static void Main()
    {
        try
        {
            Run();
        }
        catch (Exception ex)
        {
            Console.WriteLine();
            Console.WriteLine("### ERROR EN TIEMPO DE EJECUCION ###");
            Console.WriteLine(ex);
        }
        Console.WriteLine();
        Console.WriteLine("Fin. Presione una tecla para cerrar...");
        Console.ReadKey();
    }

    static void Run()
    {
        Console.WriteLine("=== SarazaFlix (Strategy + Proxy + Visitor + Repository) ===");
        var usuario = new Usuario { Id = 1, Nombre = "Franco", Plan = Plan.Basico };
        var serie = new Contenido { Id = 1, Titulo = "Serie A", EsPremium = false };
        var peli = new Contenido { Id = 2, Titulo = "Peli 4K", EsPremium = true };

        var repro = AppFactory.CrearReproductorService(usuario.Plan);
        Console.WriteLine(repro.Reproducir(usuario, serie, 60));  // 4K, ok
        Console.WriteLine(repro.Reproducir(usuario, serie, 60));  // desde cache
        Console.WriteLine(repro.Reproducir(usuario, peli, 60));   // BLOQUEADO (plan basico)
        repro.SetModoAhorro(true);
        Console.WriteLine(repro.Reproducir(usuario, serie, 60));  // baja (modo ahorro)
        Console.WriteLine("Reproducciones guardadas: " + repro.Historial().Count);

        Console.WriteLine();
        Console.WriteLine("-- Exportar listado (Visitor) --");
        var export = AppFactory.CrearExportService();
        var listado = new List<IExportable> { usuario, serie, peli };
        Console.Write(export.Exportar(listado));
    }
}
