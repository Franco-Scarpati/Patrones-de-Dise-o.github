# SarazaFlix - Nucleo de plataforma de video

**Patrones:** Strategy (calidad), Proxy (contenido remoto + plan + cache), Visitor (exportar cualquier listado), Repository (persistir reproducciones).

| Capa | Contenido |
| --- | --- |
| DomainModel | Plan, Contenido, Usuario, Reproduccion, IExportable, IExportVisitor |
| DAL | IRepositorio, RepositorioMemoria |
| Services | ILogger, ConsoleLogger |
| BLL | Patrones/EstrategiaCalidad, Patrones/ContenidoProxy, Patrones/TextoVisitor, ReproductorService, ExportService, AppFactory |
| UI | Program (reproduce, bloqueo por plan, modo ahorro, exporta) |
| Tests | SarazaFlixTests |

Mapa enunciado -> patron:
- Calidad segun conexion / modo ahorro -> **Strategy** (o State si lo ves como estados).
- Contenido remoto + bloquear por plan + cachear 5 -> **Proxy**.
- Exportar cualquier listado con una unica rutina -> **Visitor**.
- Persistir cada reproduccion -> **Repository** (DAL).
- 3+ capas -> esta misma estructura.

Abri `SarazaFlix.sln`, inicio UI, F5. Tests con `dotnet test`.
