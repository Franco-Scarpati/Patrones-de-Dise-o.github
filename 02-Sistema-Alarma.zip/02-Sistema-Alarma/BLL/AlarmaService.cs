using System.Collections.Generic;
using DomainModel;
using DAL;
using Services;
using BLL.Patrones;

namespace BLL;

public class AlarmaService
{
    private readonly IRepositorio<EventoAlarma> _repo;
    private readonly ILogger _logger;

    public AlarmaService(IRepositorio<EventoAlarma> repo, ILogger logger)
    {
        _repo = repo; _logger = logger;
    }

    public string Simular(string ubicacion, TipoAbono abono)
    {
        var sensor = new Sensor(ubicacion);
        var monitor = new SensorMonitor(sensor);
        var alarma = new Alarma(EstrategiaPara(abono), _logger);
        monitor.Suscribir(alarma);
        monitor.DetectarEvento();
        _repo.Agregar(new EventoAlarma { Ubicacion = ubicacion, Accion = alarma.UltimaAccion });
        return alarma.UltimaAccion;
    }

    public List<EventoAlarma> Historial() => _repo.ObtenerTodos();

    public static IEstrategiaDisparo EstrategiaPara(TipoAbono a)
    {
        switch (a)
        {
            case TipoAbono.Plus: return new DisparoPlus();
            case TipoAbono.Lujo: return new DisparoLujo();
            default: return new DisparoBasico();
        }
    }
}
