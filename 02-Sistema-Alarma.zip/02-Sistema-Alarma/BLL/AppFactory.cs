using DomainModel;
using DAL;
using Services;

namespace BLL;

public static class AppFactory
{
    public static AlarmaService CrearAlarmaService()
        => new AlarmaService(new RepositorioMemoria<EventoAlarma>(), new ConsoleLogger());
}
