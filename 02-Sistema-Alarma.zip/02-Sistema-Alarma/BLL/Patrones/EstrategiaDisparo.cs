namespace BLL.Patrones;

// Strategy: el algoritmo de Disparar cambia segun el abono.
public interface IEstrategiaDisparo { string Disparar(); }

public class DisparoBasico : IEstrategiaDisparo
{
    public string Disparar() => "Suena la bocina";
}
public class DisparoPlus : IEstrategiaDisparo
{
    public string Disparar() => "Llama a la central de alarmas";
}
public class DisparoLujo : IEstrategiaDisparo
{
    public string Disparar() => "Observa por camara el sitio censado";
}
