using System.Collections.Generic;
using DomainModel;
using Services;

namespace BLL.Patrones;

// Observer: la Alarma observa a los sensores.
public interface ISensorObserver { void AlDetectar(Sensor s); }

// Subject
public class SensorMonitor
{
    private readonly List<ISensorObserver> _observadores = new List<ISensorObserver>();
    private readonly Sensor _sensor;
    public SensorMonitor(Sensor sensor) { _sensor = sensor; }
    public void Suscribir(ISensorObserver o) => _observadores.Add(o);
    public void DetectarEvento()
    {
        foreach (var o in _observadores) o.AlDetectar(_sensor);
    }
}

// ConcreteObserver: usa Strategy para el disparo.
// CambiarAbono permite cambiar el tipo de abono en caliente (pregunta 2 del enunciado).
public class Alarma : ISensorObserver
{
    public long Frecuencia { get; set; }
    public int Timbre { get; set; }
    public string UltimaAccion { get; private set; }
    private IEstrategiaDisparo _estrategia;
    private readonly ILogger _logger;

    public Alarma(IEstrategiaDisparo estrategia, ILogger logger)
    {
        _estrategia = estrategia; _logger = logger;
    }
    public void CambiarAbono(IEstrategiaDisparo nueva) => _estrategia = nueva;
    public void AlDetectar(Sensor s)
    {
        UltimaAccion = _estrategia.Disparar();
        _logger.Log("Sensor en " + s.Ubicacion + " detecto evento -> " + UltimaAccion);
    }
}
