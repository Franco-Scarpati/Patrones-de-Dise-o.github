using System;
using DomainModel;
using BLL;

namespace UI;

class Program
{
    static void Main()
    {
        try
        {
            Run();
        }
        catch (Exception ex)
        {
            Console.WriteLine();
            Console.WriteLine("### ERROR EN TIEMPO DE EJECUCION ###");
            Console.WriteLine(ex);
        }
        Console.WriteLine();
        Console.WriteLine("Fin. Presione una tecla para cerrar...");
        Console.ReadKey();
    }

    static void Run()
    {
        Console.WriteLine("=== SISTEMA DE ALARMA (Observer + Strategy) ===");
        var service = AppFactory.CrearAlarmaService();
        service.Simular("Living", TipoAbono.Basico);
        service.Simular("Garage", TipoAbono.Plus);
        service.Simular("Entrada", TipoAbono.Lujo);
        Console.WriteLine("Eventos guardados en DAL: " + service.Historial().Count);
    }
}
