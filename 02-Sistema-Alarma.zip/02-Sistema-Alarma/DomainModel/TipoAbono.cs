namespace DomainModel;

public enum TipoAbono { Basico, Plus, Lujo }
