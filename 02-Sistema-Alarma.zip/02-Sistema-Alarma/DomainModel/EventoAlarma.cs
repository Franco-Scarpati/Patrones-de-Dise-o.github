namespace DomainModel;

public class EventoAlarma
{
    public string Ubicacion { get; set; }
    public string Accion { get; set; }
}
