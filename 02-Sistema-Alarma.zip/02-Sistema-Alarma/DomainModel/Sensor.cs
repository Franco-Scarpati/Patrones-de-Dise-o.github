namespace DomainModel;

public class Sensor
{
    public string Ubicacion { get; set; }
    public Sensor() { }
    public Sensor(string ubicacion) { Ubicacion = ubicacion; }
}
