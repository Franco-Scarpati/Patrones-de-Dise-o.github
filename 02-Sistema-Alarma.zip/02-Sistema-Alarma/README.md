# Sistema de alarma

**Patrones:** Observer (la alarma observa a los sensores) + Strategy (algoritmo de `Disparar` segun abono).
**Enunciado:** Basico = bocina, Plus = central telefonica, Lujo = camara. El abono puede cambiarse en caliente.

- Pregunta 1 (que clases se agregan): una estrategia por abono (DisparoBasico/Plus/Lujo). El codigo de `Disparar` no se toca: se delega en la estrategia.
- Pregunta 2 (cambio dinamico): `Alarma.CambiarAbono(...)` cambia la estrategia en runtime.

| Capa | Contenido |
| --- | --- |
| DomainModel | Sensor, TipoAbono, EventoAlarma |
| DAL | IRepositorio, RepositorioMemoria |
| Services | ILogger, ConsoleLogger |
| BLL | Patrones/EstrategiaDisparo, Patrones/AlarmaObserver, AlarmaService, AppFactory |
| UI | Program (simula 3 sensores) |
| Tests | AlarmaTests |

Abri `Alarma.sln`, inicio UI, F5. Tests con `dotnet test`.
