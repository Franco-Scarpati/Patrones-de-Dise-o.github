using DomainModel;
using BLL;
using BLL.Patrones;
using Xunit;

namespace Tests;

public class AlarmaTests
{
    [Theory]
    [InlineData(TipoAbono.Basico, "Suena la bocina")]
    [InlineData(TipoAbono.Plus, "Llama a la central de alarmas")]
    [InlineData(TipoAbono.Lujo, "Observa por camara el sitio censado")]
    public void CadaAbonoDisparaDistinto(TipoAbono abono, string esperado)
    {
        var service = AppFactory.CrearAlarmaService();
        var accion = service.Simular("Test", abono);
        Assert.Equal(esperado, accion);
    }

    [Fact]
    public void SeGuardaElEvento()
    {
        var service = AppFactory.CrearAlarmaService();
        service.Simular("Test", TipoAbono.Plus);
        Assert.Single(service.Historial());
    }

    [Fact]
    public void PuedeCambiarAbonoEnCaliente()
    {
        var alarma = new Alarma(AlarmaService.EstrategiaPara(TipoAbono.Plus), new Services.ConsoleLogger());
        alarma.AlDetectar(new Sensor("X"));
        Assert.Equal("Llama a la central de alarmas", alarma.UltimaAccion);
        alarma.CambiarAbono(AlarmaService.EstrategiaPara(TipoAbono.Lujo));
        alarma.AlDetectar(new Sensor("X"));
        Assert.Equal("Observa por camara el sitio censado", alarma.UltimaAccion);
    }
}
